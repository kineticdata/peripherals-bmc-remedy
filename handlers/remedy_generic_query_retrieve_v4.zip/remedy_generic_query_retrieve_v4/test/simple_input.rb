{
  'info' => {
    'server' => '',
    'username' => '',
    'password' => '',
    'port' => '',
    'prognum' => '',
    'authentication' => '',
    'enable_debug_logging' => 'Yes',
    'disable_caching' => 'No'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	  'form' => 'SIT:Site Alias Company LookUp',
    'request_query' => %|'Site Group Type' = "Physical"|,
    'return_type' => 'All'
  }
}
